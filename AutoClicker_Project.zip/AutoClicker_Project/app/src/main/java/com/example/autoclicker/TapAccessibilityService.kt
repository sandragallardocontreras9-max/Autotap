package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.os.Build

class TapAccessibilityService : AccessibilityService() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.autoclicker.ACTION_TAP") {
                val x = intent.getFloatExtra("x", 500f)
                val y = intent.getFloatExtra("y", 500f)
                realizarClic(x, y)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter("com.example.autoclicker.ACTION_TAP")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        Log.d("AutoTapApp", "Servicio de Accesibilidad Conectado")
    }

    fun realizarClic(x: Float, y: Float) {
        val clickPath = Path()
        clickPath.moveTo(x, y)

        val clickStroke = GestureDescription.StrokeDescription(clickPath, 0, 10)
        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(clickStroke)

        val result = dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                Log.d("AutoTapApp", "Clic en X:$x Y:$y")
            }
        }, null)

        if (!result) {
            Log.e("AutoTapApp", "Fallo al despachar el gesto.")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
    }
}