CÓMO USAR ESTE PROYECTO
========================

1. Abre Android Studio → "New Project" → "Empty Views Activity" (Kotlin).
   Nombre del paquete: com.example.autotap (importante que coincida).

2. Sustituye/copia estos archivos dentro del proyecto que creaste,
   respetando las mismas rutas:
   - app/src/main/AndroidManifest.xml
   - app/src/main/java/com/example/autotap/*.kt
   - app/src/main/res/layout/*.xml
   - app/src/main/res/drawable/*.xml
   - app/src/main/res/values/strings.xml y themes.xml
   - app/src/main/res/xml/accessibility_service_config.xml
   - app/build.gradle (revisa que las dependencias no choquen con las
     que Android Studio ya puso por defecto)

3. Sincroniza Gradle y ejecuta la app en el móvil (no en emulador,
   los overlays van mejor en dispositivo real).

CÓMO FUNCIONA
=============
- Pantalla principal: 3 botones para conceder el permiso de
  "Mostrar sobre otras apps", activar el Servicio de Accesibilidad
  (obligatorio: es lo único que permite inyectar toques reales en
  Android moderno) y lanzar el botón flotante.

- Botón flotante:
  · Pulsación LARGA (mantener ~0.5s) → abre/cierra el menú.
  · Menú → interruptor "Macro activada/desactivada":
      - DESACTIVADA: puedes arrastrar el botón a cualquier sitio.
      - ACTIVADA: el arrastre se bloquea; un toque CORTO sobre el
        botón inicia el toque ultra rápido (círculo verde) y otro
        toque corto lo detiene (círculo gris).
  · Menú → deslizador "Velocidad": ajusta el intervalo entre toques
    (10ms–500ms), en vivo si ya está tocando.
  · Menú → "Cerrar AutoTap": detiene todo y cierra el servicio.

NOTA IMPORTANTE
================
Android exige el Servicio de Accesibilidad para simular toques sobre
otras apps (no hay forma de saltarse esto sin root). Muchos juegos
online detectan y prohíben este tipo de herramientas, así que úsalo
solo donde esté permitido (apps propias, juegos offline, tareas
repetitivas legítimas, etc.).
