CÓMO USAR ESTE PROYECTO
========================

1. Abre Android Studio → "New Project" → "Empty Views Activity" (Kotlin).
   Nombre del paquete: com.example.autotap (importante que coincida).

2. Sustituye/copia estos archivos dentro del proyecto que creaste,
   respetando las mismas rutas:
   - app/src/main/AndroidManifest.xml
   - app/src/main/java/com/example/autotap/*.kt
   - app/src/main/res/layout/*.xml
   - app/src/main/res/drawable/*.xml
   - app/src/main/res/values/strings.xml y themes.xml
   - app/src/main/res/xml/accessibility_service_config.xml
   - app/build.gradle (revisa que las dependencias no choquen con las
     que Android Studio ya puso por defecto)

3. Sincroniza Gradle y ejecuta la app en el móvil (no en emulador,
   los overlays van mejor en dispositivo real).

CÓMO FUNCIONA
=============
- Pantalla principal: 3 botones para conceder el permiso de
  "Mostrar sobre otras apps", activar el Servicio de Accesibilidad
  (obligatorio: es lo único que permite inyectar toques reales en
  Android moderno) y lanzar los flotantes.

- Hay DOS elementos flotantes independientes:

  1) El BOTÓN GRANDE (⚡) — el que genera los toques:
     - Con la Macro DESACTIVADA (ver panel de ajustes): se puede
       arrastrar libremente a cualquier sitio de la pantalla.
     - Con la Macro ACTIVADA: queda FIJO (no se puede mover). Un
       TOQUE CORTO lo enciende (empieza a tocar solo, rapidísimo,
       en su misma posición) y otro TOQUE CORTO lo apaga. Cuando
       está disparando se ve a tope de color con anillo blanco;
       en reposo se ve con la transparencia normal.
       (Antes era "mantener pulsado para disparar", pero Android
       cancela cualquier toque en curso -incluido el propio dedo
       que lo mantiene pulsado- cada vez que se simula un toque,
       así que ese modo se paraba solo casi al instante. El toque
       corto para encender/apagar evita ese problema.)

  2) El ENGRANAJE (⚙) — pequeño, para no estorbar en los juegos:
     - Se puede arrastrar a cualquier sitio en todo momento.
     - Un toque corto abre/cierra su panel de ajustes.
     - Dentro del panel: interruptor Macro activada/desactivada,
       velocidad (30–500 ms), tamaño del botón grande (40–120 dp),
       intensidad/transparencia del color, 6 colores neón a elegir,
       y "Cerrar AutoTap".
     - La X del panel SOLO cierra el panel; el engranaje se queda
       visible y, si vuelves a tocarlo, el panel se vuelve a abrir
       con todo tal y como lo dejaste.

NOTA IMPORTANTE
================
Android exige el Servicio de Accesibilidad para simular toques sobre
otras apps (no hay forma de saltarse esto sin root). Muchos juegos
online detectan y prohíben este tipo de herramientas, así que úsalo
solo donde esté permitido (apps propias, juegos offline, tareas
repetitivas legítimas, etc.).

LÍMITE DE ANDROID CON TOQUES SIMULTÁNEOS
==========================================
Mientras el botón grande está disparando, cada toque sintético que
genera cancela CUALQUIER OTRO gesto que esté en curso en ese
instante en cualquier parte de la pantalla (esto lo hace Android
mismo, está documentado en su API, y no se puede desactivar sin
root). En la práctica: si en ese momento tienes otro dedo
deslizando un joystick o pulsando otro botón del juego, es normal
que note cortes o que no responda del todo bien. Se ha reducido la
duración de cada toque al mínimo para que ese corte sea lo más
breve posible, pero no se puede eliminar del todo con las APIs
públicas de Android. Si necesitas combinar el auto-toque con otros
gestos manuales, prueba a bajar la velocidad (más ms = toques más
espaciados = más hueco libre para tus otros gestos).
