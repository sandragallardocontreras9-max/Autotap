CÓMO USAR ESTE PROYECTO
========================

1. Abre Android Studio → "New Project" → "Empty Views Activity" (Kotlin).
   Nombre del paquete: com.example.autotap (importante que coincida).

2. Sustituye/copia estos archivos dentro del proyecto que creaste,
   respetando las mismas rutas:
   - app/src/main/AndroidManifest.xml
   - app/src/main/java/com/example/autotap/*.kt
   - app/src/main/res/layout/*.xml
   - app/src/main/res/drawable/*.xml
   - app/src/main/res/values/strings.xml y themes.xml
   - app/src/main/res/xml/accessibility_service_config.xml
   - app/build.gradle (revisa que las dependencias no choquen con las
     que Android Studio ya puso por defecto)

3. Sincroniza Gradle y ejecuta la app en el móvil (no en emulador,
   los overlays van mejor en dispositivo real).

CÓMO FUNCIONA
=============
- Pantalla principal: 3 botones para conceder el permiso de
  "Mostrar sobre otras apps", activar el Servicio de Accesibilidad
  (obligatorio: es lo único que permite inyectar toques reales en
  Android moderno) y lanzar los flotantes.

- Hay DOS elementos flotantes independientes:

  1) El BOTÓN GRANDE (⚡) — el que genera los toques:
     - Con la Macro DESACTIVADA (ver panel de ajustes): se puede
       arrastrar libremente a cualquier sitio de la pantalla.
     - Con la Macro ACTIVADA: queda FIJO (no se puede mover) y
       mientras mantengas el dedo apoyado sobre él, dispara toques
       ultra rápidos en su misma posición; al soltar, se detiene.

  2) El ENGRANAJE (⚙) — pequeño, para no estorbar en los juegos:
     - Se puede arrastrar a cualquier sitio en todo momento.
     - Un toque corto abre/cierra su panel de ajustes.
     - Dentro del panel: interruptor Macro activada/desactivada,
       velocidad (30–500 ms), tamaño del botón grande (40–120 dp),
       intensidad/transparencia del color, 6 colores neón a elegir,
       y "Cerrar AutoTap".
     - La X del panel SOLO cierra el panel; el engranaje se queda
       visible y, si vuelves a tocarlo, el panel se vuelve a abrir
       con todo tal y como lo dejaste.

NOTA IMPORTANTE
================
Android exige el Servicio de Accesibilidad para simular toques sobre
otras apps (no hay forma de saltarse esto sin root). Muchos juegos
online detectan y prohíben este tipo de herramientas, así que úsalo
solo donde esté permitido (apps propias, juegos offline, tareas
repetitivas legítimas, etc.).
