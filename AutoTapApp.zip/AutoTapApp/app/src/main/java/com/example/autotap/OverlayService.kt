package com.example.autotap

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.graphics.ColorUtils
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager

    // --- Botón principal (el que genera los toques) ---
    private lateinit var tapButtonView: TextView
    private lateinit var tapButtonParams: WindowManager.LayoutParams

    // --- Engranaje de ajustes (pequeño, siempre visible y movible) ---
    private lateinit var gearView: TextView
    private lateinit var gearParams: WindowManager.LayoutParams

    // --- Panel de ajustes (se añade/quita bajo demanda) ---
    private var panelView: View? = null
    private var panelParams: WindowManager.LayoutParams? = null

    // --- Estado configurable ---
    private var macroEnabled = false
    private var buttonSizeDp = 64
    private var colorBase = Color.parseColor("#39FF14")
    private var intensity = 190 // alpha 0-255
    private var intervalMs = 60L
    private var isTapping = false

    private val colorPresets = listOf(
        Color.parseColor("#39FF14"), // verde
        Color.parseColor("#00E5FF"), // azul
        Color.parseColor("#FF2D95"), // rosa
        Color.parseColor("#B026FF"), // morado
        Color.parseColor("#FF6B00"), // naranja
        Color.parseColor("#FF1744")  // rojo
    )

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupTapButton()
        setupGear()
    }

    // ============================ BOTÓN PRINCIPAL ============================

    private fun setupTapButton() {
        tapButtonView = TextView(this).apply {
            gravity = Gravity.CENTER
            text = "⚡"
            setTextColor(Color.WHITE)
        }

        tapButtonParams = WindowManager.LayoutParams(
            dp(buttonSizeDp), dp(buttonSizeDp),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 120
            y = 300
        }

        windowManager.addView(tapButtonView, tapButtonParams)
        applyButtonAppearance()
        attachTapButtonTouch()
    }

    private fun buttonDrawable(): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(ColorUtils.setAlphaComponent(colorBase, intensity))
        d.setStroke(dp(3), colorBase)
        return d
    }

    private fun applyButtonAppearance() {
        tapButtonParams.width = dp(buttonSizeDp)
        tapButtonParams.height = dp(buttonSizeDp)
        tapButtonView.background = buttonDrawable()
        tapButtonView.textSize = (buttonSizeDp / 3.4f)
        if (tapButtonView.isAttachedToWindow) {
            windowManager.updateViewLayout(tapButtonView, tapButtonParams)
        }
    }

    private var tbInitialX = 0
    private var tbInitialY = 0
    private var tbInitialTouchX = 0f
    private var tbInitialTouchY = 0f
    private var tbDragging = false
    private var tbDownTime = 0L
    private val DRAG_THRESHOLD = 12f

    private fun attachTapButtonTouch() {
        tapButtonView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    tbInitialX = tapButtonParams.x
                    tbInitialY = tapButtonParams.y
                    tbInitialTouchX = event.rawX
                    tbInitialTouchY = event.rawY
                    tbDragging = false
                    tbDownTime = System.currentTimeMillis()
                    if (macroEnabled) startTappingLoop()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!macroEnabled) {
                        val dx = event.rawX - tbInitialTouchX
                        val dy = event.rawY - tbInitialTouchY
                        if (abs(dx) > DRAG_THRESHOLD || abs(dy) > DRAG_THRESHOLD) {
                            tbDragging = true
                            tapButtonParams.x = tbInitialX + dx.toInt()
                            tapButtonParams.y = tbInitialY + dy.toInt()
                            windowManager.updateViewLayout(tapButtonView, tapButtonParams)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (macroEnabled) stopTappingLoop()
                    tbDragging = false
                    true
                }
                else -> false
            }
        }
    }

    private fun startTappingLoop() {
        if (TapAccessibilityService.instance == null) {
            Toast.makeText(
                this,
                "Activa el servicio de accesibilidad de AutoTap primero",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val location = IntArray(2)
        tapButtonView.getLocationOnScreen(location)
        val centerX = location[0] + tapButtonView.width / 2f
        val centerY = location[1] + tapButtonView.height / 2f
        TapAccessibilityService.instance?.startTapping(centerX, centerY, intervalMs)
        isTapping = true
    }

    private fun stopTappingLoop() {
        TapAccessibilityService.instance?.stopTapping()
        isTapping = false
    }

    // ============================ ENGRANAJE (AJUSTES) ============================

    private fun setupGear() {
        gearView = TextView(this).apply {
            gravity = Gravity.CENTER
            text = "⚙"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1A1A2E"))
                setStroke(dp(1), Color.parseColor("#55FFFFFF"))
            }
        }

        val size = dp(34)
        gearParams = WindowManager.LayoutParams(
            size, size,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 500
        }

        windowManager.addView(gearView, gearParams)
        attachGearTouch()
    }

    private var gInitialX = 0
    private var gInitialY = 0
    private var gInitialTouchX = 0f
    private var gInitialTouchY = 0f
    private var gDragging = false
    private var gDownTime = 0L

    private fun attachGearTouch() {
        gearView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    gInitialX = gearParams.x
                    gInitialY = gearParams.y
                    gInitialTouchX = event.rawX
                    gInitialTouchY = event.rawY
                    gDragging = false
                    gDownTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - gInitialTouchX
                    val dy = event.rawY - gInitialTouchY
                    if (abs(dx) > DRAG_THRESHOLD || abs(dy) > DRAG_THRESHOLD) {
                        gDragging = true
                        gearParams.x = gInitialX + dx.toInt()
                        gearParams.y = gInitialY + dy.toInt()
                        windowManager.updateViewLayout(gearView, gearParams)
                        panelView?.let { repositionPanel() }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val pressDuration = System.currentTimeMillis() - gDownTime
                    if (!gDragging && pressDuration < 400) {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ============================ PANEL DE AJUSTES ============================

    private fun togglePanel() {
        if (panelView != null) {
            closePanel()
        } else {
            openPanel()
        }
    }

    private fun closePanel() {
        panelView?.let { windowManager.removeView(it) }
        panelView = null
        panelParams = null
    }

    private fun repositionPanel() {
        val p = panelParams ?: return
        p.x = (gearParams.x - dp(90)).coerceAtLeast(10)
        p.y = gearParams.y + dp(44)
        panelView?.let { windowManager.updateViewLayout(it, p) }
    }

    private fun openPanel() {
        val panel = buildPanel()
        val params = WindowManager.LayoutParams(
            dp(240), ViewGroup.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (gearParams.x - dp(90)).coerceAtLeast(10)
            y = gearParams.y + dp(44)
        }
        panelView = panel
        panelParams = params
        windowManager.addView(panel, params)
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.parseColor("#9E9EB8"))
        textSize = 12f
        setPadding(0, dp(10), 0, dp(2))
    }

    private fun buildPanel(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE14141F"))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#3339FF14"))
            }
        }

        // Cabecera con título y botón cerrar (X)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "AJUSTES DEL BOTÓN"
            setTextColor(Color.parseColor("#39FF14"))
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { closePanel() }
        }
        header.addView(title)
        header.addView(closeBtn)
        root.addView(header)

        // Fila: Macro activada/desactivada
        val macroRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val macroLabel = TextView(this).apply {
            text = if (macroEnabled) "Macro: activada" else "Macro: desactivada"
            setTextColor(Color.WHITE)
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val macroSwitch = Switch(this).apply { isChecked = macroEnabled }
        macroSwitch.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
            macroEnabled = checked
            macroLabel.text = if (checked) "Macro: activada" else "Macro: desactivada"
            if (!checked) stopTappingLoop()
        }
        macroRow.addView(macroLabel)
        macroRow.addView(macroSwitch)
        root.addView(macroRow)
        root.addView(TextView(this).apply {
            text = "Activada: el botón queda fijo y toca mientras lo mantienes pulsado.\nDesactivada: puedes arrastrarlo."
            setTextColor(Color.parseColor("#9E9EB8"))
            textSize = 10f
        })

        // Velocidad
        val speedLabel = sectionLabel("Velocidad: ${intervalMs} ms")
        root.addView(speedLabel)
        val speedBar = SeekBar(this).apply {
            max = 470
            progress = (intervalMs - 30).toInt().coerceIn(0, 470)
        }
        speedBar.setOnSeekBarChangeListener(simpleSeek { progress ->
            intervalMs = (progress + 30).toLong()
            speedLabel.text = "Velocidad: ${intervalMs} ms"
            if (isTapping) TapAccessibilityService.instance?.updateInterval(intervalMs)
        })
        root.addView(speedBar)

        // Tamaño
        val sizeLabel = sectionLabel("Tamaño: ${buttonSizeDp} dp")
        root.addView(sizeLabel)
        val sizeBar = SeekBar(this).apply {
            max = 80
            progress = (buttonSizeDp - 40).coerceIn(0, 80)
        }
        sizeBar.setOnSeekBarChangeListener(simpleSeek { progress ->
            buttonSizeDp = progress + 40
            sizeLabel.text = "Tamaño: ${buttonSizeDp} dp"
            applyButtonAppearance()
        })
        root.addView(sizeBar)

        // Intensidad (transparencia)
        val intensityLabel = sectionLabel("Intensidad: ${intensity * 100 / 255}%")
        root.addView(intensityLabel)
        val intensityBar = SeekBar(this).apply {
            max = 215
            progress = (intensity - 40).coerceIn(0, 215)
        }
        intensityBar.setOnSeekBarChangeListener(simpleSeek { progress ->
            intensity = progress + 40
            intensityLabel.text = "Intensidad: ${intensity * 100 / 255}%"
            applyButtonAppearance()
        })
        root.addView(intensityBar)

        // Colores
        root.addView(sectionLabel("Color"))
        val colorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        colorPresets.forEach { c ->
            val swatch = View(this).apply {
                val lp = LinearLayout.LayoutParams(dp(28), dp(28))
                lp.marginEnd = dp(8)
                layoutParams = lp
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    if (c == colorBase) setStroke(dp(2), Color.WHITE)
                }
                setOnClickListener {
                    colorBase = c
                    applyButtonAppearance()
                    closePanel()
                    openPanel()
                }
            }
            colorRow.addView(swatch)
        }
        root.addView(colorRow)

        // Cerrar app
        val closeAppLabel = TextView(this).apply {
            text = "Cerrar AutoTap"
            setTextColor(Color.parseColor("#FF1744"))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
            setOnClickListener {
                stopTappingLoop()
                stopSelf()
            }
        }
        root.addView(closeAppLabel)

        return root
    }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTappingLoop()
        closePanel()
        if (::tapButtonView.isInitialized && tapButtonView.isAttachedToWindow) {
            windowManager.removeView(tapButtonView)
        }
        if (::gearView.isInitialized && gearView.isAttachedToWindow) {
            windowManager.removeView(gearView)
        }
    }
}
