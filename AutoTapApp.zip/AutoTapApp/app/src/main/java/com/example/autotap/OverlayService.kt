package com.example.autotap

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.CompoundButton
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var rootView: View
    private lateinit var params: WindowManager.LayoutParams

    private var macroEnabled = false      // false = modo edición (mover/ajustar), true = modo activo (toca al pulsar)
    private var intervalMs = 60L          // velocidad de toque
    private var isTapping = false

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private var downTime = 0L

    private val LONG_PRESS_MS = 450L
    private val DRAG_THRESHOLD = 12f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        rootView = LayoutInflater.from(this).inflate(R.layout.overlay_button, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 100
        params.y = 300

        windowManager.addView(rootView, params)
        setupViews()
    }

    private fun setupViews() {
        val button = rootView.findViewById<TextView>(R.id.floatingButton)
        val menuPanel = rootView.findViewById<View>(R.id.menuPanel)
        val macroSwitch = rootView.findViewById<Switch>(R.id.macroSwitch)
        val macroStateLabel = rootView.findViewById<TextView>(R.id.macroStateLabel)
        val speedLabel = rootView.findViewById<TextView>(R.id.speedLabel)
        val speedSeekBar = rootView.findViewById<SeekBar>(R.id.speedSeekBar)
        val closeAppButton = rootView.findViewById<TextView>(R.id.closeAppButton)

        speedSeekBar.progress = (intervalMs - 10).toInt().coerceIn(0, 490)
        speedLabel.text = "Velocidad: ${intervalMs} ms"

        macroSwitch.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
            macroEnabled = checked
            macroStateLabel.text = if (checked) "Macro activada" else "Macro desactivada"
            if (!checked) {
                // Al desactivar, paramos cualquier toque en curso
                stopTappingLoop()
                button.setBackgroundResource(R.drawable.circle_off)
            }
        }

        speedSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                intervalMs = (progress + 10).toLong()
                speedLabel.text = "Velocidad: ${intervalMs} ms"
                if (isTapping) {
                    TapAccessibilityService.instance?.updateInterval(intervalMs)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        closeAppButton.setOnClickListener {
            stopTappingLoop()
            stopSelf()
        }

        button.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    downTime = System.currentTimeMillis()

                    // Con la macro activada, el toque rápido empieza en el instante
                    // en que el dedo baja sobre el botón flotante.
                    if (macroEnabled) {
                        startTappingLoop(button)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (!macroEnabled) {
                        // Solo se puede arrastrar cuando la macro está desactivada
                        if (kotlin.math.abs(dx) > DRAG_THRESHOLD || kotlin.math.abs(dy) > DRAG_THRESHOLD) {
                            isDragging = true
                            params.x = initialX + dx.toInt()
                            params.y = initialY + dy.toInt()
                            windowManager.updateViewLayout(rootView, params)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val pressDuration = System.currentTimeMillis() - downTime

                    if (macroEnabled) {
                        // Al soltar el botón, el toque rápido se detiene siempre.
                        stopTappingLoop()
                        button.setBackgroundResource(R.drawable.circle_off)
                    }

                    if (!isDragging && pressDuration >= LONG_PRESS_MS) {
                        // Pulsación larga (sin arrastrar): abrir/cerrar menú
                        menuPanel.visibility = if (menuPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    }

                    isDragging = false
                    true
                }
                else -> false
            }
        }
    }

    private fun startTappingLoop(button: TextView) {
        val location = IntArray(2)
        button.getLocationOnScreen(location)
        val centerX = location[0] + button.width / 2f
        val centerY = location[1] + button.height / 2f
        TapAccessibilityService.instance?.startTapping(centerX, centerY, intervalMs)
        isTapping = true
        button.setBackgroundResource(R.drawable.circle_on)
    }

    private fun stopTappingLoop() {
        TapAccessibilityService.instance?.stopTapping()
        isTapping = false
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTappingLoop()
        if (::rootView.isInitialized) {
            windowManager.removeView(rootView)
        }
    }
}
