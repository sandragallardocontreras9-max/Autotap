package com.example.autotap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TapAccessibilityService? = null
        private const val TAG = "AutoTapService"
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var tapping = false
    private var intervalMs = 50L
    private var x = 0f
    private var y = 0f

    private val loop = Runnable { performTap() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Servicio de accesibilidad conectado")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTapping()
        instance = null
    }

    fun startTapping(tapX: Float, tapY: Float, interval: Long) {
        x = tapX
        y = tapY
        intervalMs = interval.coerceAtLeast(30L)
        if (tapping) return
        tapping = true
        handler.removeCallbacksAndMessages(null)
        performTap()
    }

    fun updateInterval(interval: Long) {
        intervalMs = interval.coerceAtLeast(30L)
    }

    fun stopTapping() {
        tapping = false
        handler.removeCallbacksAndMessages(null)
    }

    fun isTapping() = tapping

    private fun performTap() {
        if (!tapping) return
        val path = Path()
        path.moveTo(x, y)
        // La duración del toque siempre es menor que el intervalo, para dejar
        // hueco al siguiente toque sin que se solapen.
        val duration = (intervalMs - 15L).coerceIn(16L, 60L)
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (tapping) handler.postDelayed(loop, (intervalMs - duration).coerceAtLeast(5L))
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (tapping) handler.postDelayed(loop, intervalMs)
            }
        }, null)

        if (!dispatched) {
            Log.w(TAG, "dispatchGesture devolvió false, reintentando en ${intervalMs}ms")
            if (tapping) handler.postDelayed(loop, intervalMs)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
