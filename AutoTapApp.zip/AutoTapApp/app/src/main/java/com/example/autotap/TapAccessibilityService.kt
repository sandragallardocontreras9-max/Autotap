package com.example.autotap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TapAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var tapping = false
    private var intervalMs = 50L
    private var x = 0f
    private var y = 0f

    private val loop = object : Runnable {
        override fun run() {
            if (!tapping) return
            performTap()
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        stopTapping()
    }

    fun startTapping(tapX: Float, tapY: Float, interval: Long) {
        x = tapX
        y = tapY
        intervalMs = interval.coerceAtLeast(10L)
        if (tapping) return
        tapping = true
        handler.post(loop)
    }

    fun updateInterval(interval: Long) {
        intervalMs = interval.coerceAtLeast(10L)
    }

    fun stopTapping() {
        tapping = false
        handler.removeCallbacks(loop)
    }

    fun isTapping() = tapping

    private fun performTap() {
        val path = Path()
        path.moveTo(x, y)
        val stroke = GestureDescription.StrokeDescription(path, 0, 8L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
