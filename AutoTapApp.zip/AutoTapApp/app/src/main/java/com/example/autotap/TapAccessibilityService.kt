package com.example.autotap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TapAccessibilityService? = null
        private const val TAG = "AutoTapService"
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var tapping = false
    private var intervalMs = 50L
    private var x = 0f
    private var y = 0f

    // Bucle independiente: programa el SIGUIENTE toque a un intervalo fijo
    // sin esperar ninguna confirmación del toque anterior. Esto es a
    // propósito: depender del callback de dispatchGesture (onCompleted/
    // onCancelled) puede dejar el bucle colgado para siempre en móviles
    // donde ese callback no llega de forma fiable.
    private val loop = object : Runnable {
        override fun run() {
            if (!tapping) return
            performTap()
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Servicio de accesibilidad conectado")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTapping()
        instance = null
    }

    fun startTapping(tapX: Float, tapY: Float, interval: Long) {
        x = tapX
        y = tapY
        intervalMs = interval.coerceAtLeast(30L)
        if (tapping) return
        tapping = true
        handler.removeCallbacksAndMessages(null)
        handler.post(loop)
    }

    fun updateInterval(interval: Long) {
        intervalMs = interval.coerceAtLeast(30L)
    }

    fun stopTapping() {
        tapping = false
        handler.removeCallbacksAndMessages(null)
    }

    fun isTapping() = tapping

    private fun performTap() {
        val path = Path().apply {
            moveTo(x, y)
            // Un micro-movimiento de 1px en vez de un punto totalmente
            // quieto: algunos fabricantes ignoran gestos de longitud cero.
            lineTo(x + 1f, y + 1f)
        }
        val duration = (intervalMs / 2).coerceIn(16L, 70L)
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val dispatched = dispatchGesture(gesture, null, null)
        if (!dispatched) {
            Log.w(TAG, "dispatchGesture devolvió false en x=$x y=$y")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
