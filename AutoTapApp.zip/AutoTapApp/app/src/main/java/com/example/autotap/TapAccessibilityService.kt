package com.example.autotap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class TapAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TapAccessibilityService? = null
        private const val TAG = "AutoTapService"
        private const val MAX_CONSECUTIVE_FAILURES = 5
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var tapping = false
    private var intervalMs = 50L
    private var x = 0f
    private var y = 0f
    private var consecutiveFailures = 0

    // Bucle independiente: programa el SIGUIENTE toque a un intervalo fijo
    // sin esperar ninguna confirmación del toque anterior. Esto es a
    // propósito: depender del callback de dispatchGesture (onCompleted/
    // onCancelled) puede dejar el bucle colgado para siempre en móviles
    // donde ese callback no llega de forma fiable.
    private val loop = object : Runnable {
        override fun run() {
            if (!tapping) return
            performTap()
            if (tapping) handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Servicio de accesibilidad conectado")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTapping()
        instance = null
    }

    fun startTapping(tapX: Float, tapY: Float, interval: Long) {
        x = tapX
        y = tapY
        intervalMs = interval.coerceAtLeast(30L)
        if (tapping) return
        tapping = true
        consecutiveFailures = 0
        handler.removeCallbacksAndMessages(null)
        handler.post(loop)
    }

    fun updateInterval(interval: Long) {
        intervalMs = interval.coerceAtLeast(30L)
    }

    fun stopTapping() {
        tapping = false
        handler.removeCallbacksAndMessages(null)
    }

    fun isTapping() = tapping

    private fun performTap() {
        val path = Path().apply {
            moveTo(x, y)
            // Un micro-movimiento de 1px en vez de un punto totalmente
            // quieto: algunos fabricantes ignoran gestos de longitud cero.
            lineTo(x + 1f, y + 1f)
        }
        // IMPORTANTE: Android cancela CUALQUIER otro gesto en curso en toda
        // la pantalla (el del usuario, el de este servicio o el de otro)
        // cada vez que se llama a dispatchGesture. Es un comportamiento
        // documentado de la API, no un bug nuestro, y no hay forma de
        // desactivarlo sin root. Cuanto más corto sea nuestro toque
        // sintético, menos tiempo "roba" a otro dedo que esté tocando o
        // deslizando en ese preciso instante, así que usamos la duración
        // mínima que sigue siendo fiable en vez de escalarla con el
        // intervalo completo.
        val duration = (intervalMs / 3).coerceIn(16L, 40L)
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                consecutiveFailures = 0
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                // Normal: casi siempre es otro toque (real o nuestro) que
                // tomó prioridad justo en ese instante. No cuenta como fallo.
            }
        }, handler)

        if (!dispatched) {
            consecutiveFailures++
            Log.w(TAG, "dispatchGesture devolvió false en x=$x y=$y (fallo $consecutiveFailures)")
            if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
                Log.e(TAG, "Demasiados fallos seguidos: el sistema rechaza los toques. Deteniendo.")
                Toast.makeText(
                    this,
                    "AutoTap se detuvo: el sistema rechazó los toques repetidamente",
                    Toast.LENGTH_LONG
                ).show()
                stopTapping()
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
